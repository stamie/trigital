CREATE TABLE users (
    id int NOT NULL auto_increment,
    fullname varchar(255) not null,
    username varchar(255) not null,
    userpassword varchar(255) not null,
    is_use bool,
    PRIMARY KEY (id)
);